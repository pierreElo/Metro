
package metro;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Metro {

    private HashMap<Integer,Ligne> tabLignes;

    
    public Metro() {
        this.tabLignes = new HashMap<Integer, Ligne>();
    }


    public void ajouterLigne(Ligne l){
        tabLignes.put(l.getId(), l);
    }

    public HashMap<Integer, Ligne> getTabLignes() {
        return tabLignes;
    }

    public void setTabLignes(HashMap<Integer, Ligne> tabLignes) {
        this.tabLignes = tabLignes;
    }

    public List getAllVoie () {
        List<Voie> v = new ArrayList <Voie> ();
        
            for (int i=0; i<this.tabLignes.size(); i++) {
                //for (int j=0 ; j<=this.tabLignes.get(i).getListeVoies().size(); j++) {
                    System.out.println(this.tabLignes.get(0));
                //    v.add(this.tabLignes.get(i).getListeVoies().get(j));
                //}
                    
            }
        return v;
            }
    

 }
