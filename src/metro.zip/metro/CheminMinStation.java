
package metro;

import java.util.*;

/**
 *
 * @author Elodie 
 */


public class CheminMinStation{
  //  private static Station stationActuelle;
//  private int coutDistance;
    //liste de tous les chemins stockés
    private final Metro metro;
    private static List <Chemin> cheminsPossibles;
    private static List <Voie> voies;
    private static int coutTotal;

    public CheminMinStation(Metro metro) {
        this.metro = metro;
        this.cheminsPossibles = new ArrayList();
        
        this.coutTotal=0;
    }

    
    public static List<Station> getVoisins(Station station){
        System.out.println("get voisins");
        System.out.println(voies.size());
        List<Station> voisins = new ArrayList();
        for(int i=0; i<voies.size(); i++){
            System.out.println("for");
            if(voies.get(i).getStationAval().equals(station)){
                System.out.println("1");
                voisins.add(voies.get(i).getStationAval());
            }
            else if (voies.get(i).getStationAmont().equals(station)) {
                System.out.println("2");
                voisins.add(voies.get(i).getStationAmont());
            }
        }
        return voisins;
    }
    
    /*
    public static Chemin algoRecherche(Station stationActuelle, Station arrivee){
        Station stationTraitee = stationActuelle;
        System.out.println("\ndans algo !!!!!!");
        System.out.println("station actuelle : " + stationActuelle.getNom());

        List voisins = new ArrayList();
        Chemin ch = new Chemin(0);     
        ch.getParcours().add(stationActuelle);

        cheminsPossibles.add(ch);
        Main.afficherListesChemins(cheminsPossibles);
        // tant qu'on est pas arrivée
        if(stationActuelle!=arrivee){
          //  voisins = getVoisins(stationTraitee);
            System.out.println(cheminsPossibles.get(0).getParcours().get(0).getNom());
            stationTraitee=cheminsPossibles.get(0).getParcours().get(0);
            
            int j=cheminsPossibles.size()-1;
            for(int i=0; i<=voisins.size(); i++){
                cheminsPossibles.get(j).getParcours().get(0);
                j++;
            }
            
            coutTotal++;
            cheminsPossibles.remove(0);
         //   algoRecherche(cheminsPossibles.get(0).getParcours().get(0),arrivee);
        }
        //Main.afficherListesChemins(cheminsPossibles);
        return ch;
    }*/
    
    
}
